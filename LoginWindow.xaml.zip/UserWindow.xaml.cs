﻿using Microsoft.Win32;
using NAudio.Wave;
using System.Data.SqlClient;
using System.IO;
using System.Windows;

namespace LovedOnes
{
    public partial class UserWindow : Window
    {
        WaveInEvent waveSource;
        WaveFileWriter waveFile;
        string filePath = "recorded.wav";
        string username;

        public UserWindow(string user)
        {
            InitializeComponent();
            username = user;
        }

        private void Record_Click(object sender, RoutedEventArgs e)
        {
            waveSource = new WaveInEvent();
            waveSource.WaveFormat = new WaveFormat(44100, 1);
            waveSource.DataAvailable += WaveSource_DataAvailable;

            waveFile = new WaveFileWriter(filePath, waveSource.WaveFormat);

            waveSource.StartRecording();
            MessageBox.Show("Recording Started");
        }

        private void WaveSource_DataAvailable(object sender, WaveInEventArgs e)
        {
            waveFile.Write(e.Buffer, 0, e.BytesRecorded);
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            waveSource.StopRecording();
            waveFile.Dispose();

            SaveVoice(filePath);
            MessageBox.Show("Saved to Database");
        }

        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Wav Files|*.wav";

            if (open.ShowDialog() == true)
            {
                SaveVoice(open.FileName);
                MessageBox.Show("Uploaded");
            }
        }

        private void SaveVoice(string path)
        {
            byte[] data = File.ReadAllBytes(path);

            using (SqlConnection con =
                new SqlConnection(DatabaseHelper.connectionString))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Voices VALUES(@u,@v)", con);

                cmd.Parameters.AddWithValue("@u", username);
                cmd.Parameters.AddWithValue("@v", data);

                cmd.ExecuteNonQuery();
            }
        }
    }
}