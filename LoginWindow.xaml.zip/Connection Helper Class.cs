﻿namespace LovedOnes
{
    public class DatabaseHelper
    {
        public static string connectionString =
            @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=LovedOnesDB;Integrated Security=True";
    }
}