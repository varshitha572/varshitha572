﻿using System.Windows;

namespace LovedOnes
{
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
        }
    }
}