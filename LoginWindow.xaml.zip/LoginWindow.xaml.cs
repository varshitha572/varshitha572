﻿using System.Data.SqlClient;
using System.Windows;

namespace LovedOnes
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Password;

            using (SqlConnection con =
                new SqlConnection(DatabaseHelper.connectionString))
            {
                con.Open();

                string query = "SELECT Role FROM Users WHERE Username=@u AND Password=@p";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@u", username);
                cmd.Parameters.AddWithValue("@p", password);

                object role = cmd.ExecuteScalar();

                if (role != null)
                {
                    if (role.ToString() == "Admin")
                    {
                        new AdminWindow().Show();
                    }
                    else
                    {
                        new UserWindow(username).Show();
                    }

                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Login");
                }
            }
        }
    }
}